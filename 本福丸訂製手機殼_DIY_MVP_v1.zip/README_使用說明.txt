本福丸訂製手機殼 DIY MVP v1

這版已完成可操作 MVP：
- Apple iPhone 11~17 Pro Max 型號資料
- 5 種手機殼款式
- Fabric.js DIY 畫布
- 多張照片上傳、拖曳、縮放、旋轉
- 圖片左右/上下翻轉、透明度、圖層前後、複製、刪除
- AI 去背獨立 API 模擬介面 /api/ai/remove-background
- 貼紙庫與素材
- 文字（字型、大小、粗體、斜體、顏色）
- 模板與照片插槽
- 我的作品（瀏覽器 localStorage）：保存、繼續編輯、複製、刪除
- 2D 預覽
- 購物車 / 結帳 / 訂單輸出
- 訂單保存 production PNG、mockup、design JSON
- 後台型號 / 殼款 / 價格 / 貼紙 / 模板 / 訂單管理

啟動：
1. pip install -r requirements.txt
2. python app.py
3. 瀏覽器打開 http://localhost:8080
4. 後台 http://localhost:8080/admin

Zeabur：直接推送整個資料夾內容即可。

注意：
- 目前資料仍使用 JSON + 本機檔案，Zeabur 重部署可能清空；Supabase 持久化是下一階段。
- AI 去背目前為模擬介面，真正去背服務可直接替換 /api/ai/remove-background。
- 生產尺寸目前沿用你既有 print_w/print_h 與 Fabric 輸出邏輯，正式量產前仍需用實體機殼/工廠刀模校正 DPI、出血與鏡頭孔。
